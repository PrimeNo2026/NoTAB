package de.tabtoggle;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.List;
import java.util.Locale;
import java.util.stream.Stream;

public final class TabTogglePlugin extends JavaPlugin implements Listener, TabExecutor {

    private static final String PERMISSION = "tabtoggle.use";
    private boolean tabEnabled;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        tabEnabled = getConfig().getBoolean("tab-enabled", true);

        Bukkit.getPluginManager().registerEvents(this, this);

        var command = getCommand("tab");
        if (command != null) {
            command.setExecutor(this);
            command.setTabCompleter(this);
        }

        applyToAll();
        getLogger().info("TabToggle aktiv. TAB ist aktuell " + (tabEnabled ? "AN" : "AUS") + ".");
    }

    @Override
    public void onDisable() {
        // Beim Entladen die Liste wieder normal anzeigen
        apply(true);
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        if (tabEnabled) {
            return;
        }
        // Einen Tick warten, damit der Client die Einträge sicher schon kennt
        Bukkit.getScheduler().runTask(this, this::applyToAll);
    }

    private void applyToAll() {
        apply(tabEnabled);
    }

    /** Paper-API: listPlayer/unlistPlayer gelten pro Betrachter, daher für jedes Spielerpaar. */
    private void apply(boolean listed) {
        for (Player viewer : Bukkit.getOnlinePlayers()) {
            for (Player target : Bukkit.getOnlinePlayers()) {
                if (listed) {
                    viewer.listPlayer(target);
                } else {
                    viewer.unlistPlayer(target);
                }
            }
        }
    }

    private void setTabEnabled(boolean enabled) {
        tabEnabled = enabled;
        getConfig().set("tab-enabled", enabled);
        saveConfig();
        applyToAll();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission(PERMISSION)) {
            sender.sendMessage(Component.text("Dazu hast du keine Berechtigung.", NamedTextColor.RED));
            return true;
        }
        if (args.length != 1) {
            sender.sendMessage(Component.text("Benutzung: /" + label + " <on|off|status>", NamedTextColor.YELLOW));
            return true;
        }

        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "on" -> {
                setTabEnabled(true);
                sender.sendMessage(Component.text("TAB-Liste wurde ", NamedTextColor.GRAY)
                        .append(Component.text("aktiviert", NamedTextColor.GREEN))
                        .append(Component.text(".", NamedTextColor.GRAY)));
            }
            case "off" -> {
                setTabEnabled(false);
                sender.sendMessage(Component.text("TAB-Liste wurde ", NamedTextColor.GRAY)
                        .append(Component.text("deaktiviert", NamedTextColor.RED))
                        .append(Component.text(".", NamedTextColor.GRAY)));
            }
            case "status" -> sender.sendMessage(Component.text("TAB-Liste ist aktuell ", NamedTextColor.GRAY)
                    .append(tabEnabled
                            ? Component.text("AN", NamedTextColor.GREEN)
                            : Component.text("AUS", NamedTextColor.RED)));
            default -> sender.sendMessage(Component.text("Benutzung: /" + label + " <on|off|status>", NamedTextColor.YELLOW));
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (!sender.hasPermission(PERMISSION) || args.length != 1) {
            return List.of();
        }
        String prefix = args[0].toLowerCase(Locale.ROOT);
        return Stream.of("on", "off", "status").filter(s -> s.startsWith(prefix)).toList();
    }
}
