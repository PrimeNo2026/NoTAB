# TabToggle

Paper-Plugin (Paper 26.3, Java 25; nutzt Player#unlistPlayer/listPlayer), das die TAB-Spielerliste ein- und ausschaltet.

- `/tab on` – TAB-Liste aktivieren
- `/tab off` – TAB-Liste deaktivieren
- `/tab status` – aktuellen Zustand anzeigen

Permission: `tabtoggle.use` (Standard: nur OPs). Der Zustand bleibt nach einem Neustart erhalten.
